﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp5
{
    public static class Crypt
    {
        public static string ToBinary(int n)
        {
            string result = "";
            while (n > 0)
            {
                result += (n % 2).ToString();
                n /= 2;
            }
            while (result.Length < 8)
            {
                result += '0';
            }
            string res2 = "";
            for (int i = result.Length - 1; i >= 0; i--)
            {
                res2 += result[i];
            }
            return result;
        }
        public static int ToString(string s) 
        {
            int result = 0;
            for (int i = 0; i < s.Length; i++)
            {
                if (s[i] == '1')
                {
                    result += (int)Math.Pow(2, i);
                }
            }
            return result;
        }
    }
}
