﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int index = 0;
            foreach (var item in richTextBox1.Text)
            {
                richTextBox2.Text += " ";
                richTextBox2.Text += Crypt.ToBinary(item);
                index++;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int index = 0;
            string[] strings = richTextBox1.Text.Split(' ');
            foreach (var item in strings)
            {
                richTextBox2.Text += " ";
                richTextBox2.Text += Crypt.ToString(item);
                index++;
            }
        }
    }
}
